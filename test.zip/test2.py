import os
import sys
sys.path.append("/home/gdl1/gdl")


print('test2입니다.')
print('\n')

import test3
test3()